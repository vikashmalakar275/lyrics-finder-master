export type AutoSearchDBObject = {
  guildID: string;
  channelID: string;
}
