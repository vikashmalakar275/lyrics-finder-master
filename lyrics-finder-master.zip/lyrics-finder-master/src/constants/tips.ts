const Tips: string[] = [
  'Support server: https://discord.gg/mhUdNPZ', // Invite link for Footer https://discord.gg/mhUdNPZ
  'Use `~!np` to display your current Spotify song',
  'Lyrics not found? Add it to https://genius.com',
  'Found bugs or errors? Report it to the support server!',
  'Support the bot - https://lyrics-finder.angeloanan.xyz/support',
  'Changelog - https://lyrics-finder.angeloanan.xyz/changelog'
]

export default Tips
