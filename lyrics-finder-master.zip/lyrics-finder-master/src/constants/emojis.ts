
export const LoadingEmoji = '<a:loading:697741386199597156>'
