# Lyrics Finder TODO List

* Search by YouTube Title / Content ID Description
* Search using Spotify URL
* Autoplay / Spotify - consider using romanized lyrics
* Scrolling Lyrics (When lyrics gets too long)
* Search Menu (Query search)
* Complete unit test